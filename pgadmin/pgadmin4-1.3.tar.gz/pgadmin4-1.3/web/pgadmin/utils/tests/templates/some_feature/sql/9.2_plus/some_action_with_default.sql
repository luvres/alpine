Some other feature 9.2 SQL
