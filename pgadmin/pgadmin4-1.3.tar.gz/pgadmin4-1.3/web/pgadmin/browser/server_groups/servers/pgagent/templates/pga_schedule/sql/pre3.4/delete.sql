{% import 'macros/pga_schedule.macros' as SCHEDULE %}
{{ SCHEDULE.DELETE(jid, jscid) }}
