{% import 'macros/pga_jobstep.macros' as STEP %}
{{ STEP.PROPERTIES(has_connstr, jid, jstid) }}
