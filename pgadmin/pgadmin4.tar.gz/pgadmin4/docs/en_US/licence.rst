.. _licence:

*******
Licence
*******

pgAdmin is released under the  `PostgreSQL Licence <http://www.postgresql.org/about/licence>`_, which is a  liberal Open Source licence similar to BSD or MIT, and approved by the Open  Source Initiative. The copyright for the project source code, website and documentation is attributed to the `pgAdmin Development Team <https://www.pgadmin.org/development/team.php>`_.