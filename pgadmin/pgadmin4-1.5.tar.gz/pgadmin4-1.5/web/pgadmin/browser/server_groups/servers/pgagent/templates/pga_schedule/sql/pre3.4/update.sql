{% import 'macros/pga_schedule.macros' as SCHEDULE %}
{{ SCHEDULE.UPDATE(jid, jscid, data) }}
