SELECT jclid AS value, jclname AS label FROM pgagent.pga_jobclass
