{% import 'macros/pga_jobstep.macros' as STEP %}
{{ STEP.DELETE(jid, jstid) }}
