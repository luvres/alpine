{% import 'macros/pga_schedule.macros' as SCHEDULE %}
{{ SCHEDULE.INSERT(jid, data) }}
