define(function () {
  var translations = {{ translations|tojson }};
  return translations;
});